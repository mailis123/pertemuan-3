// Membuat array names
const names = ["Michael", "Hannah", "Jonas"];

/**
 * Menjalankan method forEach.
 * Method forEach bertujuan untuk iterasi.
 */
names.forEach(function (name) {
  console.log(`Nama: ${name}`);
});
